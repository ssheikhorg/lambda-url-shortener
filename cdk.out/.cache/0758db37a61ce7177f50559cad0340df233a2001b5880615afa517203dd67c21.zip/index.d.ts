export declare function handler(event: AWSLambda.CloudFormationCustomResourceEvent): Promise<void>;
